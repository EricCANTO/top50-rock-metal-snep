
import datetime
import requests
import os

# Déterminer la semaine ISO actuelle
today = datetime.date.today()
year, week_num, _ = today.isocalendar()

# Construire l'URL
base_url = "https://snepmusique.com/pdf/tops_pdf.php"
params = f"?annee={year}&semaine={week_num}&categorie=Top%20Rock%20%26%20Metal"
url = base_url + params

# Créer le dossier de sortie s'il n'existe pas
os.makedirs("data", exist_ok=True)
filename = f"data/Top-Rock-Metal-SNEP-{year}-W{week_num}.pdf"

# Télécharger le PDF
response = requests.get(url)
if response.status_code == 200:
    with open(filename, "wb") as f:
        f.write(response.content)
    print(f"✅ PDF téléchargé : {filename}")
else:
    print(f"❌ Erreur {response.status_code} lors de l'accès à {url}")
